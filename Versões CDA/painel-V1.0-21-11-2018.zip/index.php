<?php
   session_start();
   if(!empty($_SESSION['id_usuario']) AND $_SESSION['permissao'] != 1){
    include_once("conection/conexao.php");
    $idfuncionario = $_SESSION['id_usuario'];
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Models Painel Admin</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href="assets/css/lib/vector-map/jqvmap.min.css" rel="stylesheet">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
    <!-- GRAFICO DE APROVEITAMENTO MENSAL -->
    <?php
        /* $result_contagem_agendamento = "SELECT id_func FROM agendamentos WHERE id_func = $idfuncionario";
        $resultado_contagem_agendamento = mysqli_query($conn, $result_contagem_agendamento);
        $resultado_final_contagem_agendamento = mysqli_num_rows($resultado_contagem_agendamento);

        $mes = 10;
        $result_contagem_fichas_liberadas = "SELECT qtd_fichas_liberadas FROM fichas_limpas WHERE id_func = $idfuncionario AND MONTH(data_liberada_fichas_limpas) = $mes ";
        $resultado_contagem_fichas_liberadas = mysqli_query($conn, $result_contagem_fichas_liberadas);
        $cont = 0;
        while ($exibe = mysqli_fetch_assoc($resultado_contagem_fichas_liberadas) ) {
            $cont = $cont + $exibe['qtd_fichas_liberadas'];
        } */
        


    ?>
    <!--
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Fichas Liberadas',     <?php echo $cont; ?>],
          ['Agendamentos',      <?php echo $resultado_final_contagem_agendamento; ?>],
         
        ]);

        var options = {
          title: 'Aproveitamento de Fichas Mensal',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
<!-- FINALIZANDO GRAFICO DE APROVEITAMENTO MENSAL -->
</head>
<body>
    <?php
        include_once("includes/inc_menu.php");
    ?>
    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php
            include_once("includes/inc_header.php");
         ?>
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <font size="6px"> Àrea de Notificações</font>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo "São Paulo, ".date("d/m/Y"); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">

            <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                  <span class="badge badge-pill badge-success"> <font size="3px"> Logado como: <?php echo $_SESSION['nome_funcionario']; ?> <?php  echo $_SESSION['menu_scouter_ligacao'];  ?> </font></span>  
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <!-- TESTE INDEX SCOUTER -->
                <div class="card col-md-6 no-padding ">
                                <div class="card-body">
                                    <div class="h1 text-muted text-right mb-4">
                                        <i class="fa fa-user-plus"></i>
                                    </div>
                                    <div class="h4 mb-0">
                                        <span class="count">
                                            <?php
                                                $contagem_agendamento = "SELECT id_agendamentos FROM agendamentos WHERE id_func = '$idfuncionario' AND DATE(data_cadastro_agendamento) = DATE(NOW())";
                                                $resultado_contagem_agendamento = mysqli_query($conn, $contagem_agendamento);
                                                $resultado_final_agendamento = mysqli_num_rows($resultado_contagem_agendamento);
                                                echo $resultado_final_agendamento;
                                            ?>
                                        </span>
                                    </div>
                                    <small class="text-muted text-uppercase font-weight-bold">Novos Agendamentos (Dia)</small>
                                    <div class="progress progress-xs mt-3 mb-0 bg-flat-color-2" style="width: 40%; height: 5px;"></div>
                                </div>
                            </div>
                <!-- -->
                <!-- TESTE BONIFICAÇÃO -->
                <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-money text-success border-success"></i></div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Bonificação(Mês)</div>
                                        <div class="stat-digit">
                                        <?php
                                            $comissao_mensal = "SELECT id_agendamentos FROM agendamentos WHERE id_func = '$idfuncionario' AND MONTH(data_cadastro_agendamento) = MONTH(NOW())";
                                            $result_comissao_mensal = mysqli_query($conn, $comissao_mensal);
                                            $resultado_comissao_mensal = mysqli_num_rows($result_comissao_mensal);
                                            $comissao_final = $resultado_comissao_mensal * 2;
                                            echo "R$".$comissao_final.",00";
                                        ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <!-- -->
                <!--AGENDADOS MENSAL -->
                <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-layout-grid2 text-warning border-warning"></i></div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Agendados(Mês)</div>
                                        <div class="stat-digit"><?php echo $resultado_comissao_mensal; ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- -->
                    <!-- Comparecimentos (Mensal) -->
                        <div class="col-lg-3 col-md-6">
                        <div class="card" style="width: 480px;">
                            <div class="card-body">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-user text-primary border-primary"></i></div>
                                    <div class="stat-content dib">
                                        <div class="stat-text">Comparecimentos(Mês)</div>
                                        <div class="stat-digit">
                                            <?php
                                                $confirmados_mes = "SELECT id_agendamentos FROM agendamentos WHERE id_func = '$idfuncionario' AND id_comparecimento = '1' AND MONTH(data_agendada_agendamento) = MONTH(NOW())";
                                                $result_confirmados_mes = mysqli_query($conn, $confirmados_mes);
                                                $resultado_confirmados_mes = mysqli_num_rows($result_confirmados_mes);
                                                echo $resultado_confirmados_mes;

                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- -->

                    </div>
            <div class="col-sm-6 col-lg-3">         
                
            </div> 


        </div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="assets/js/lib/vector-map/country/jquery.vmap.world.js"></script>
    <script>
        ( function ( $ ) {
            "use strict";

            jQuery( '#vmap' ).vectorMap( {
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: [ '#1de9b6', '#03a9f5' ],
                normalizeFunction: 'polynomial'
            } );
        } )( jQuery );
    </script>

</body>
</html>
<?php
    }else{
        $_SESSION['msg'] = "<div class='alert alert-info' role='alert'>
                                            Àrea Restrita!
                             </div>";
        header("Location: loginpage.php");

    };
?>
