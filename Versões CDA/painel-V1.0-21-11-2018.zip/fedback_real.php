<?php
class Authenticator {

  public static $username = "hugo";
  public static $password = "1234";

  public static function check() {
    if (
      isset($_SERVER['PHP_AUTH_USER']) &&
      isset($_SERVER['PHP_AUTH_PW']) &&
      $_SERVER['PHP_AUTH_USER'] == self::$username &&
      $_SERVER['PHP_AUTH_PW'] == self::$password
    ) {
      return true;
    } else {
      header('WWW-Authenticate: Basic realm="Please login."');
      header('HTTP/1.0 401 Unauthorized');
      die("Usuário ou senha incorretos!");
    }
  }

}

if(Authenticator::check()){
  echo "";
  $pagina = "content.html";
  if(isset($_POST)){
    if(isset($_POST["conteudo"])){
      $fopen = fopen($pagina,"w+");
      fwrite($fopen,$_POST["conteudo"]);
      fclose($fopen);
    }
  }
}
else return null;
?>
<head>
<meta charset="utf8">
<title> Resumo Temporário </title>
</head>
<body>
<?php
include_once("conection/conexao.php");


?>

<center>
<div id="teste">  
<table border="1" style="float: left">
  <tr>
    <td colspan="5"><font size="9px"> Quantidade de Agendados HOJE </font> </td>
  </tr>
  <tr>
    <td>Funcionário</td>
    <td>Exclusive Matriz</td>
    <td>Exclusive Lapa</td>
    <td>Impact Agency</td>
  </tr>
  <tr>


  </tr>
</table>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<table border="1" style="float: left;"> 
  <tr>
    <td colspan="3"><font size="9px">  Pausas do Dia </font> </td>
  </tr>
  <tr>
    <td> Funcionário </td>
    <td> Hora da Pausa </td>
    <td> Horário de Volta </td>
  </tr>
</table>
</div>




</body>
</html>