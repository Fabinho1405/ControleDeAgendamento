<?php
	session_start();
	unset($_SESSION['id_usuario'], $_SESSION['nome_usuario'], $_SESSION['nome_funcionario'], $_SESSION['permissao'] , $_SESSION['id_funcionario'] );


	$_SESSION['msg'] = "<div class='alert alert-info' role='alert'>
                                            Deslogado com Sucesso!
                             </div>";
						header("Location: ../loginpage.php");





?>