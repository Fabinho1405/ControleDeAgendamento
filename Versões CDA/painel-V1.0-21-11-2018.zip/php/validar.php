<?php

	session_start();
	include_once("../conection/conexao.php");

	$btnLogin = filter_input(INPUT_POST, 'btn_login', FILTER_SANITIZE_STRING);

	if($btnLogin){
		$usuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING);
		$senha = filter_input(INPUT_POST, 'senha', FILTER_SANITIZE_STRING);

		//echo "$usuario - $senha" ;

		if(!empty($usuario) AND !empty($senha)){
			//gerar senha cripto
			//echo password_hash("$senha", PASSWORD_DEFAULT);

			$result_validar = "SELECT * FROM funcionario WHERE usuario_func = '$usuario' LIMIT 1;";
			$resultado_validar = mysqli_query($conn, $result_validar);

			if($resultado_validar){
				$row_usuario = mysqli_fetch_assoc($resultado_validar);

					if(password_verify($senha, $row_usuario['senha_func'])){
						if($row_usuario['status_sistema'] == 1){
						//GLOBAIS
						$_SESSION['id_usuario']= $row_usuario['id_func'];
						$_SESSION['nome_usuario'] = $row_usuario['usuario_func'];
						$_SESSION['nome_funcionario'] = $row_usuario['nome_completo_func'];
						$_SESSION['menu_scouter_ligacao'] = $row_usuario['menu_scouter_ligacao'];
						$_SESSION['menu_scouter_insta'] = $row_usuario['menu_scouter_insta'];
						$_SESSION['menu_confirmacao'] = $row_usuario['menu_confirmacao'];
						$_SESSION['menu_supervisao'] = $row_usuario['menu_supervisao'];
						$_SESSION['menu_gerencia'] = $row_usuario['menu_gerencia'];
						$_SESSION['permissao'] = $row_usuario['permissao'];

						header("Location: ../index.php");

					}else{
						$_SESSION['msg'] = "<div class='alert alert-warning' role='alert'>
                                           Conta Restringida Pela <b> Gerência </b> ! Entre em contato com o seu gestor para mais informações.
                             </div>";
						header("Location: ../loginpage.php");

					}
					}else{
						$_SESSION['msg'] = "<div class='alert alert-info' role='alert'>
                                            Login e Senha INCORRETOS!
                             </div>";
						header("Location: ../loginpage.php");
					}
			}


		}else{
			$_SESSION['msg'] = "<div class='alert alert-info' role='alert'>
                                            Login e Senha INCORRETOS!
                             </div>";
		header("Location: ../loginpage.php");
		}
	}else{
		$_SESSION['msg'] = "<div class='alert alert-danger' role='alert'>
                                            Conecte-se corretamente ou contate o Suporte Tecnico central.
                             </div>";
		header("Location: ../loginpage.php");

	}
	


?>