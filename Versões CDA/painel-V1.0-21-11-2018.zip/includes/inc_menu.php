
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="images/logonovo.png" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"> <i class="menu-icon fa fa-home"></i>Pagina Inicial</a>
                    </li>

                    <!-- MENU DE SCOUTER'S LIGAÇÃO-->
                    <?php  
                        if($_SESSION['menu_scouter_ligacao'] == 1){
                    ?>
                    <h3 class="menu-title">Scouter (Ligação) </h3><!-- /.menu-title -->
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-calendar"></i>Agendamentos</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-calendar"></i><a href="cadastrar_agendamento_ligacao.php">Cadastrar Agendamento</a></li>                            
                            <li><i class="fa fa-calendar"></i><a href="lista_telefonica.php">Fichas Liberadas</a></li>
                            <li><i class="fa fa-calendar"></i><a href="visualizar_agendamento.php">Visualizar Agendamentos</a></li>
                        </ul>
                    </li>
                <?php }; ?>
                <!-- FIM MENU DE SCOUTER'S LIGAÇÃO -->

                <!-- MENU DE SCOUTER'S INSTAGRAM -->
                    <?php  
                        if($_SESSION['menu_scouter_insta'] == 1){
                    ?>
                    <h3 class="menu-title">Scouter (Instagram) </h3><!-- /.menu-title -->
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-calendar"></i>Agendamentos</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-calendar"></i><a href="cadastrar_agendamento_insta.php">Cadastrar Agendamento</a></li>                            
                            <li><i class="fa fa-calendar"></i><a href="visualizar_agendamento.php">Visualizar Agendamentos</a></li>
                             <li><i class="fa fa-calendar"></i><a href="reagendar_cliente.php">Reagendar Cliente</a></li>
                        </ul>
                    </li>
                <?php }; ?>
                <!-- FIM MENU DE SCOUTER'S INSTAGRAM -->

                <!-- MENU DE CONFIRMAÇÃO -->
                    <?php  
                        if($_SESSION['menu_confirmacao'] == 1){
                    ?>
                    <h3 class="menu-title">Confirmação </h3><!-- /.menu-title -->
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-calendar"></i>Confirmação</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-calendar"></i><a href="parametro_confirmacao.php">Confirmar</a></li>                            
                            <li><i class="fa fa-calendar"></i><a href="recuperar.php">Recuperar</a></li>
                             <li><i class="fa fa-calendar"></i><a href="baixar.php">Baixar CSV</a></li>
                        </ul>
                    </li>
                <?php }; ?>
                <!-- FIM MENU DE CONFIRMAÇÃO -->
                             
                    <h3 class="menu-title">Extras</h3><!-- /.menu-title -->
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-exclamation"></i>Ajuda</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-exclamation"></i><a href="uso_sistema.php">Uso do Sistema</a></li>
                            <li><i class="fa fa-exclamation"></i><a href="script_padrao.php">Scripts Padrões</a></li>
                            <li><i class="fa fa-exclamation"></i><a href="politica_privacidade.php">Política de Privacidade</a></li>
                            
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->