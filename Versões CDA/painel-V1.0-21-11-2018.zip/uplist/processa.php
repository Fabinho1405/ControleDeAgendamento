<?php

	include_once("../conection/conexao.php");
	
	//$dados = $_FILES['arquivo'];
	//var_dump($dados);
	
	if(!empty($_FILES['arquivo']['tmp_name'])){
		$arquivo = new DomDocument();
		$arquivo->load($_FILES['arquivo']['tmp_name']);
		//var_dump($arquivo);
		
		$linhas = $arquivo->getElementsByTagName("Row");
		//var_dump($linhas);
		
		$primeira_linha = true;
		
		foreach($linhas as $linha){
			if($primeira_linha == false){
				$nome_responsavel = $linha->getElementsByTagName("Data")->item(0)->nodeValue;
				echo "Responsável: $nome_responsavel <br>";
				
				$nome_modelo = $linha->getElementsByTagName("Data")->item(1)->nodeValue;
				echo "Modelo: $nome_modelo <br>";
				
				$telefone_principal = $linha->getElementsByTagName("Data")->item(2)->nodeValue;
				echo "Telefone Principal: $telefone_principal<br>";

				$telefone_secundario = $linha->getElementsByTagName("Data")->item(3)->nodeValue;
				echo "Telefone Secundario: $telefone_secundario<br>";

				$id_funcionario = $linha->getElementsByTagName("Data")->item(4)->nodeValue;
				echo "Scouter: $id_funcionario<br>";
				
				echo "<hr>";
				
				//Inserir o usuário no BD
				$result_usuario = "INSERT INTO controle_fichas (nome_responsavel_controle, nome_modelo_controle, telefone_principal_controle, telefone_secundario_controle, id_func, id_extracao, created, fb_1, fb_2, fb_3, fb_4, fb_5, fb_6, fb_7, id_status_sistema, fb_1_hour, fb_2_hour, fb_3_hour, fb_4_hour, fb_5_hour, fb_6_hour, fb_7_hour) VALUES ('$nome_responsavel', '$nome_modelo', '$telefone_principal', '$telefone_secundario', '$id_funcionario','0', NOW(), '1','0','0','0','0','0','0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL)";
				$resultado_usuario = mysqli_query($conn, $result_usuario);
			}
			$primeira_linha = false;
		}
	}
?>