<?php
	
	SELECT cli.nome_cliente Nome_Modelo, cli.nome_responsavel_cliente Responsável_Cliente, cli.telefone_cliente Telefone_Principal, cli.telefone2_cliente Telefone_Secundario, fun.nome_completo_func Scouter FROM agendamentos ag
INNER JOIN cliente cli ON ag.id_cliente = cli.id_cliente
INNER JOIN funcionario fun ON ag.id_func = fun.id_func




?>


ns1
ns2.dominios.uol.com.br
ns3