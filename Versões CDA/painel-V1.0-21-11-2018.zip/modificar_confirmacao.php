<?php
	
	include_once("conection/conexao.php");
	$select = $_POST['select_status'];
	$idagendamento = $_GET['idagendamento'];

	if($select == 1){
		echo "Em Aberto AINDA";
	}else if($select == 2){
		$insert_confirmar_usuario = "UPDATE agendamentos SET confirmado = 1, confirmado_hour = NOW() WHERE id_agendamentos = $idagendamento";
				mysqli_query($conn, $insert_confirmar_usuario);
				$var = "<script>javascript:history.back(-2)</script>";
				echo $var;
	}else if($select == 3 || $select == 4 || $select == 5 || $select == 6 || $select == 7 || $select == 8 ){

		$result_confirmacao = "SELECT * FROM agendamentos WHERE id_agendamentos = $idagendamento";
		$resultado_confirmacao = mysqli_query($conn, $result_confirmacao);
		while($row_confirmacao = mysqli_fetch_assoc($resultado_confirmacao)){

		if($row_confirmacao['fbc_4'] <> 0){		
				$insert_off = "UPDATE agendamentos SET id_status_sistema = 0 WHERE id_agendamentos = $idagendamentos";
				mysqli_query($conn, $insert_off);
				$var = "<script>javascript:history.back(-2)</script>";
				echo $var;
			}else if($row_confirmacao['fbc_1'] == 1){
				$insert_fbc1 = "UPDATE agendamentos SET fbc_1 = $select, fbc_1_hour = NOW() WHERE id_agendamentos = $idagendamento";
				mysqli_query($conn, $insert_fbc1);
				$var = "<script>javascript:history.back(-2)</script>";
				echo $var;
			}else if($row_confirmacao['fbc_2'] == 0){
				 $insert_fbc2 = "UPDATE agendamentos SET fbc_2 = $select, fbc_2_hour = NOW() WHERE id_agendamentos = $idagendamento";
				mysqli_query($conn, $insert_fbc2);
				$var = "<script>javascript:history.back(-2)</script>";
				echo $var;
			}else if($row_confirmacao['fbc_3'] == 0){
				$insert_fbc3 = "UPDATE agendamentos SET fbc_3 = $select, fbc_3_hour = NOW() WHERE id_agendamentos = $idagendamento";
				mysqli_query($conn, $insert_fbc3);
				$var = "<script>javascript:history.back(-2)</script>";
				echo $var;
			}else if($row_confirmacao['fbc_4'] == 0){
				 $insert_fbc4 = "UPDATE agendamentos SET fbc_4 = $select, fbc_4_hour = NOW() WHERE id_agendamentos = $idagendamento";
				mysqli_query($conn, $insert_fbc4);
				$var = "<script>javascript:history.back(-2)</script>";
				echo $var;
			}
		}
	}





		




?>